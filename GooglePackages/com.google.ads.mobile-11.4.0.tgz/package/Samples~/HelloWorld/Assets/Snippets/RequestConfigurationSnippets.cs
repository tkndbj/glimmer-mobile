// Copyright 2026 Google LLC

using UnityEngine;
using GoogleMobileAds.Api;
using System.Collections.Generic;

namespace GoogleMobileAds.Snippets
{
    /// <summary>
    /// Code snippets used for the developer guides.
    /// </summary>
    internal class RequestConfigurationSnippets
    {
        // Replace with your own test device ID.
        private const string TEST_DEVICE_ID = "2077ef9a63d2b398840261c8221a0c9b";

        private void SetTestDeviceIds()
        {
            // [START set_test_device_ids]
            List<string> testDeviceIds = new List<string>();
            testDeviceIds.Add(TEST_DEVICE_ID);

            RequestConfiguration requestConfiguration = new RequestConfiguration
            {
                TestDeviceIds = testDeviceIds
            };
            // [END set_test_device_ids]

            // [START set_request_configuration]
            MobileAds.SetRequestConfiguration(requestConfiguration);
            // [END set_request_configuration]
        }

        private void SetChildAgeTreatment()
        {
            // [START set_child_age_treatment]
            RequestConfiguration requestConfiguration = new RequestConfiguration
            {
                // Indicate that ad requests should have child age treatment.
                AgeRestrictedTreatment = AgeRestrictedTreatment.Child
            };
            MobileAds.SetRequestConfiguration(requestConfiguration);
            // [END set_child_age_treatment]
        }

        private void SetTeenAgeTreatment()
        {
            // [START set_teen_age_treatment]
            RequestConfiguration requestConfiguration = new RequestConfiguration
            {
                // Indicate that ad requests should have teen age treatment.
                AgeRestrictedTreatment = AgeRestrictedTreatment.Teen
            };
            MobileAds.SetRequestConfiguration(requestConfiguration);
            // [END set_teen_age_treatment]
        }

        private void SetUnspecifiedAgeTreatment()
        {
            // [START set_unspecified_age_treatment]
            RequestConfiguration requestConfiguration = new RequestConfiguration
            {
                // Indicate that ad requests should have unspecified age treatment.
                AgeRestrictedTreatment = AgeRestrictedTreatment.Unspecified
            };
            MobileAds.SetRequestConfiguration(requestConfiguration);
            // [END set_unspecified_age_treatment]
        }

        private void SetUnderAgeOfConsent()
        {
            // [START set_under_age_of_consent]
            RequestConfiguration requestConfiguration = new RequestConfiguration
            {
                TagForUnderAgeOfConsent = TagForUnderAgeOfConsent.True
            };
            MobileAds.SetRequestConfiguration(requestConfiguration);
            // [END set_under_age_of_consent]
        }

        private void SetAdContentFiltering()
        {
            // [START set_ad_content_filtering]
            RequestConfiguration requestConfiguration = new RequestConfiguration
            {
                MaxAdContentRating = MaxAdContentRating.G
            };
            MobileAds.SetRequestConfiguration(requestConfiguration);
            // [END set_ad_content_filtering]
        }
    }
}